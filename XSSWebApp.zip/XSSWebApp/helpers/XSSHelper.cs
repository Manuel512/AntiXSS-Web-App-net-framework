﻿using Ganss.XSS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XSSWebApp.helpers
{
    /// <summary>
    /// Helper class for dealing with Cross-Site scripting
    /// </summary>
    public static class XSSHelper
    {
        private static HtmlSanitizer _htmlSanitizer;

        static XSSHelper()
        {
            _htmlSanitizer = new HtmlSanitizer();
        }

        public static string SanitizeUrl(string url)
        {
            //string path = url.Split('?').FirstOrDefault();
            //var parameters = url.Split('?').LastOrDefault();

            //var queryParams = HttpUtility.ParseQueryString(parameters);

            //foreach (var key in queryParams.AllKeys)
            //{
            //    queryParams[key] = HttpUtility.UrlEncode(Sanitize(queryParams.Get(key)));
            //}

            //return $"{path}?{queryParams}";

            return "";
        }

        public static string Sanitize(string value) => _htmlSanitizer.Sanitize(value);

    }
}