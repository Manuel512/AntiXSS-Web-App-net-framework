﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using XSSWebApp.helpers;

namespace XSSWebApp.filters
{
    public class XSSProtectionFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var request = actionContext.HttpContext.Request;
            if (request.RequestType == "POST")
            {
                if (actionContext.ActionParameters != null)
                {
                    //IDictionary<string, object> newActionParameters = new Dictionary<string, object>();
                    foreach (var parameter in actionContext.ActionParameters)
                    {
                        if (CheckXSSInProperties(actionContext, parameter.Value))
                        {
                            break;
                        }
                        //var type = parameter.Value.GetType();
                        //var value = parameter.Value;
                        //var name = parameter.Key;

                        //if (type == typeof(string) && value != null)
                        //{

                        //    string sanitizedValue = XSSHelper.Sanitize(value.ToString());

                        //    if (sanitizedValue.ToString() != value.ToString())
                        //    {
                        //        actionContext.Result = new HttpStatusCodeResult(HttpStatusCode.Forbidden, "There are characters not allowed on the payload");
                        //    }
                        //}
                        //else if (type.GetProperties().Length > 0)
                        //{

                        //}
                    }

                    //actionContext.ActionParameters = newActionParameters;
                }
            }

            base.OnActionExecuting(actionContext);
        }

        private bool CheckXSSIfString(ActionExecutingContext actionContext, object value)
        {
            if (value.GetType() == typeof(string) && value != null)
            { 
                string sanitizedValue = XSSHelper.Sanitize(value.ToString());

                if (sanitizedValue.ToString().Length < value.ToString().Length)
                {
                    actionContext.Result = new HttpStatusCodeResult(HttpStatusCode.Forbidden, "There are characters not allowed on the payload");
                    return true;
                }
            
            }

            return false;
        }

        private bool CheckXSSInProperties(ActionExecutingContext actionContext, object objectValue)
        {
            if (objectValue == null) return false;
            
            var type = objectValue.GetType();

            if (type == typeof(string))
            {
                if (CheckXSSIfString(actionContext, objectValue))
                {
                    return true;
                }
            }
            else if (type.IsGenericType || type.IsArray)
            {
                foreach (var item in objectValue as IEnumerable<object>)
                {
                    if (CheckXSSInProperties(actionContext, item))
                    {
                        return true;
                    }
                }
            }
            else if (type.GetProperties().Length > 0)
            {
                foreach (var prop in objectValue.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                {
                    var value = prop.GetValue(objectValue);
                    if (CheckXSSInProperties(actionContext, value))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}